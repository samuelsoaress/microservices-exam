package com.cap.tecnologia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TecnologiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
