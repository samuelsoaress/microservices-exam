package com.cap.tecnologia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TecnologiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TecnologiaApplication.class, args);
	}

}
